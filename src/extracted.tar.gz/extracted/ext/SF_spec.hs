module SF_spec where

import qualified Prelude

type Coq_rankSelection candidate = [] candidate

type Coq_ballot candidate = [] (Coq_rankSelection candidate)

